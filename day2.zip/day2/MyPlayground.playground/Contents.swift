//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

//multiline str
var greet = """
Haalo friends,
How are you doing!
Cludy weather...
Boring class
Funny Friends
"""

print(greet)

let db = """
Saa
Re

"""
print(db)

//swift unicode sequance for emojis
let mood = "\u{1f496}"
print(mood)
//chechk eather the param is emptyy or not
if mood.isEmpty{
print("No mood!")
}
else
{greet += mood
}
print (greet)

//str obj
var team = String()
team = "Croatia"
print(team)

//to get individual char of the string
for i in team{
    print(i)
}
//chaacer is class datatype
//append char into tr or str into str
var initial : Character = "D"
team.append(initial)
print(team)

team.append(" Go Go Go")
print(team)
//to get the length of str

print("Length of team :", team.count)

//startIndex will give u th obj of that index class so we have to put it like this:
print("Start Index of team: \(team[team.startIndex])")
//it will return u index obj

//endIndex will return char after the last index
//u cnt get the endIndex chra
//print("end Index of Team : \(team[team.endIndex])")

//index method=
//index after \ before
//before - char before the index we have specfies
print("last char of team: \(team[team.index(before: team.endIndex)])")

print("Some Character: \(team[team.index(after:team.startIndex)])")
//offset by : to skip some positions
print("4th char: \(team[team.index(team.startIndex,offsetBy: 3)])")
//3rd char means 0 ,1,2,3

print("6th char: \(team[team.index(team.endIndex,offsetBy: -5)])")

var idx = team.index(team.endIndex,offsetBy: -5)
print("\(team[idx])")

//inices is colection of each inividual char's index
//it will be used for
//for index in greet.indicies {
//    print("\(greet[index])",terminator:"_")
//}
//enumarated method usd when we need the value and its index
//each enum will give u tuple containing (index , literal value)
print()
for (index,value) in team.enumerated(){
   // print("Index: \(index) --- Value : \(value)")
}

team.insert("!",at: team.endIndex)

//contentsOf lable:->
team.insert(contentsOf: "Win it...",at:team.endIndex)
//to insert some value at some char
//to insert a string lable to use: contentsOf

// of lable :-> if string is contaning this char or not
var idx1 = team.index(of: "D") ?? team.endIndex // or M
//?? for if char is not available than go for endINDEX
print("idx1 : \(idx1)")
team.remove(at: idx1)//remove will ask u for a space from where we want to remove some char
//team.removeAll(at: idx1)
//uppercased nd lowercased to convert the string

var idxG = team.index(of: "G") ?? team.endIndex
team.removeSubrange(team.startIndex...idxG)

print(team)

//to extraxt a string from a string
var idxI = team.index(of: "t") ?? team.endIndex
var idxW = team.index(of: "W") ?? team.startIndex
var win = team[idxW..<idxI]
print("\(win)")
//Win i
var idxLast = win.index(win.endIndex, offsetBy: -2)
win = win[win.startIndex...]

print("\(win)")
 print(team.uppercased())


var grade : String?
grade = "A"
let finalGrade = grade ?? "F"
print("\(finalGrade)")
















