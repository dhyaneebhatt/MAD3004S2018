//
//  Extensions.swift
//  day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//property,subscript,func,init
extension Double{
    var asCurrency: String
    {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(for: self)!
    }
}
//asCurrency is a var which will reurn a same string but after applying formatter, formatter type of currency and currency will be base on the machine we use and base on that it will alocate the currrency logo
//dateformatter, string formatter are there to format the string or data
//its only for double datatype
//for double if u want to have 42,000 u can write as 42_000
//extension: to add the functionlity into the project
extension Int{
    var isPrime: Bool
    {
        guard self > 1
        else
        {
            return false
        }
        for i in 2..<self
        {
            if self % i == 0
            {
                return false
            }
        }
        return true
    }
    
    func wish(task: () -> Void)
    {
        for _ in 1...self
        {
             task()
        }
    }
    //to get the index of digit from right
//e.g. 12345[1] will return 4
    subscript(digitIndex: Int) -> Int
    {
        var decimalBase = 1
        for _ in 0..<digitIndex
            {
                decimalBase *= 10
        }
        return (self/decimalBase) % 10
    }
}
//gaurd = exception handling

extension String
{
    var length : Int
    {
        return self.count
    }
}
