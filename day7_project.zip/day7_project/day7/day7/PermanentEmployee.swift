//
//  PermanentEmployee.swift
//  day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PermanentEmployee : Employee, INetPayCalculation
    //dont have to implement iDisplay its already there in employee class so just use its methods
{
    var vacationWeek : Int?
    //read only computed property
    var netPay : Double?
    {
        get
        {
            if self.vacationWeek! > 3
            {
                return self.basicPay! - 100
            }
            else
            {
                return self.basicPay!
            }
        }
    }
    override required init()
    {
        self.vacationWeek = 0
        super.init()
    }
    
    required init(empID: Int, empName: String, basicPay: Double, vacation holiday: Int)
    {
        super.init(empID: empID, empName: empName, basicPay: basicPay)
        self.vacationWeek = holiday
    }
    //when we call super class init it will some time cause error so put in this case put it at the end
    //1st get ready with this class properties nd then go for super class
    
    override func display()
    {
        super.display()
        print("vacation weeks: \(self.vacationWeek ?? 0)")
        print("Net pay: \(self.netPay?.asCurrency ?? self.basicPay?.asCurrency ?? 0.0.asCurrency)")
        //net pay is computed vLUE SO WE CAN NOT MAKE IT OPTIONAL FOR THAT WE HAVE TO DO CHANGES and use another value that can be optional like here we have used basic pay as option
    }
}
