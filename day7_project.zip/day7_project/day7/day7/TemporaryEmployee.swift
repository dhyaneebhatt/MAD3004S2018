//
//  TemporaryEmployee.swift
//  day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TemporaryEmployee: Employee, INetPayCalculation
{
    var hoursHoliday: Int?
    var netPay: Double?
    {
        get
        {
            if hoursHoliday! > 10
            {
                return self.basicPay! - 100
            }
            else
            {
                return self.basicPay!
            }
        }
    }
    required init(empID: Int, empName: String, basicPay: Double, vacation holiday: Int)
    {
        super.init(empID: empID, empName: empName, basicPay: basicPay)
        self.hoursHoliday = holiday
    }
    override func display()
    {
        super.display()
        print("Hours of holiday: \(self.hoursHoliday ?? 0)")
        print("Net pay: \(self.netPay?.asCurrency ?? self.basicPay?.asCurrency ?? 0.0.asCurrency)")
        //net pay is computed vLUE SO WE CAN NOT MAKE IT OPTIONAL FOR THAT WE HAVE TO DO CHANGES and use another value that can be optional like here we have used basic pay as option
    }
}
