//
//  Employee.swift
//  day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Employee : IDisplay
{
    func display()
    {
        print("Emp ID: \(self.empID ?? 0)")
        print("EmpName: \(self.empName ?? "Unknown")")
        print("BasicPay: \(self.basicPay?.asCurrency ?? 0.0.asCurrency)")
        
    }
    
    var empID : Int?
    var empName : String?
    var basicPay : Double?
    
    init()
    {
        self.empID = 0
        self.empName = ""
        self.basicPay = 0.0
    }
    
    init(empID: Int, empName: String, basicPay : Double)
    {
        self.empID = empID
        self.empName = empName
        self.basicPay = basicPay
        
    }
    
  //  func displayData()
   // {
   //     print("Emp ID: \(self.empID ?? 0)")
   //     print("EmpName: \(self.empName ?? "Unknown")")
   //     print("BasicPay: \(self.basicPay ?? 0.0)")
   // }
    //deinitializer
    //garbage collector
    deinit
    {
        print("Employee resigning the job... Hand over all the documents to employer")
    }
}
